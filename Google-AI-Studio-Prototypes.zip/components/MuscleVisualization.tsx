import React, { useState, useCallback, useMemo } from 'react';
import { MuscleVisualizationProps, MuscleId, TooltipData, MuscleState } from '../types';
import { MUSCLE_NAMES } from '../constants';
import { Tooltip } from './Tooltip';
import { MuscleMap } from './MuscleMap';

const getFatigueClasses = (percentage: number): string => {
  if (percentage < 33) return 'fill-[#22c55e]/60 [filter:drop-shadow(0_0_5px_#22c55e)]'; // Low fatigue
  if (percentage < 66) return 'fill-[#facc15]/60 [filter:drop-shadow(0_0_5px_#facc15)]'; // Medium fatigue
  return 'fill-[#ef4444]/60 [filter:drop-shadow(0_0_5px_#ef4444)]'; // High fatigue
};

export const MuscleVisualization: React.FC<MuscleVisualizationProps> = ({
  muscles,
  onMuscleClick,
  onMuscleHover,
  width = '100%',
  height = 'auto',
  hideTooltip = false,
}) => {
  const [tooltipData, setTooltipData] = useState<TooltipData | null>(null);

  const muscleDataMap = useMemo(() => {
    return muscles.reduce((acc, muscle) => {
      acc[muscle.muscleId] = muscle;
      return acc;
    }, {} as Record<MuscleId, MuscleState>);
  }, [muscles]);

  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (tooltipData) {
      const rect = e.currentTarget.getBoundingClientRect();
      setTooltipData(prev => prev ? { ...prev, x: e.clientX - rect.left, y: e.clientY - rect.top } : null);
    }
  }, [tooltipData]);

  const handleMouseLeave = useCallback(() => {
    setTooltipData(null);
    if (onMuscleHover) {
      onMuscleHover(null);
    }
  }, [onMuscleHover]);

  const handleMuscleInteraction = (
    e: React.MouseEvent<SVGElement> | React.TouchEvent<SVGElement>,
    muscleId: MuscleId
  ) => {
    e.preventDefault();
    e.stopPropagation();
    const muscle = muscleDataMap[muscleId];
    if (!muscle) return;

    if (e.type === 'click' || e.type === 'touchend') {
        if (onMuscleClick) onMuscleClick(muscleId);
        
        // On mobile, tap toggles tooltip
        if ('touches' in e.nativeEvent) {
             if (tooltipData?.muscleId === muscleId) {
                setTooltipData(null);
                if (onMuscleHover) onMuscleHover(null);
             } else {
                const target = e.currentTarget as SVGElement;
                const svg = target.ownerSVGElement;
                if(svg){
                    const rect = svg.getBoundingClientRect();
                    const targetRect = target.getBoundingClientRect();
                    setTooltipData({
                        muscleId: muscle.muscleId,
                        fatiguePercentage: muscle.fatiguePercentage,
                        x: targetRect.left - rect.left + targetRect.width / 2,
                        y: targetRect.top - rect.top + targetRect.height / 2,
                    });
                    if (onMuscleHover) onMuscleHover(muscleId);
                }
             }
        }

    } else if (e.type === 'mouseenter') {
        setTooltipData({
            muscleId: muscle.muscleId,
            fatiguePercentage: muscle.fatiguePercentage,
            x: 0, 
            y: 0,
        });
        if (onMuscleHover) onMuscleHover(muscleId);
    }
  };


  return (
    <div
      className="relative w-full h-full"
      style={{ width, height }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <MuscleMap
          view="front"
          muscleData={muscleDataMap}
          getFatigueClasses={getFatigueClasses}
          onMuscleInteraction={handleMuscleInteraction}
        />
        <MuscleMap
          view="back"
          muscleData={muscleDataMap}
          getFatigueClasses={getFatigueClasses}
          onMuscleInteraction={handleMuscleInteraction}
        />
      </div>
      {!hideTooltip && tooltipData && (
        <Tooltip
          muscleName={MUSCLE_NAMES[tooltipData.muscleId]}
          fatiguePercentage={tooltipData.fatiguePercentage}
          position={{ x: tooltipData.x, y: tooltipData.y }}
        />
      )}
    </div>
  );
};
