import React from 'react';
import { MuscleId, MuscleState } from '../types';

// FIX: Define a common interface for shared props to improve type inference.
interface CommonMuscleProps {
  muscleData: Record<MuscleId, MuscleState>;
  getFatigueClasses: (percentage: number) => string;
  onMuscleInteraction: (
    e: React.MouseEvent<SVGElement> | React.TouchEvent<SVGElement>,
    muscleId: MuscleId
  ) => void;
}

interface MuscleMapProps extends CommonMuscleProps {
  view: 'front' | 'back';
}

interface MuscleGroupProps extends CommonMuscleProps {
  id: MuscleId;
  d: string;
}

const MuscleGroup: React.FC<MuscleGroupProps> = ({ id, d, muscleData, getFatigueClasses, onMuscleInteraction }) => {
  const muscle = muscleData[id];
  const colorClass = muscle ? getFatigueClasses(muscle.fatiguePercentage) : 'fill-gray-700/30';
  
  return (
    <g
      onClick={(e) => onMuscleInteraction(e, id)}
      onMouseEnter={(e) => onMuscleInteraction(e, id)}
      onTouchEnd={(e) => onMuscleInteraction(e, id)}
      className="cursor-pointer"
    >
      <path
        d={d}
        className={`${colorClass} stroke-gray-500/50 stroke-[1.5] transition-all duration-300 ease-in-out hover:brightness-125`}
      />
    </g>
  );
};

// SVG paths for front view
// FIX: Use the new CommonMuscleProps type.
const FrontView = (props: CommonMuscleProps) => (
  <svg viewBox="0 0 400 600" className="w-full h-auto max-w-sm">
    <g id="body-outline" className="fill-gray-800/80 stroke-gray-600 stroke-1">
      {/* Head */}
      <path d="M175 90 C 160 50, 240 50, 225 90 C 230 115, 215 130, 200 130 C 185 130, 170 115, 175 90 Z" />
      {/* Neck */}
      <path d="M190 130 L 185 150 H 215 L 210 130 Z" />
      {/* Torso */}
      <path d="M185 150 C 170 160, 150 180, 150 220 L 155 340 H 245 L 250 220 C 250 180, 230 160, 215 150 H 185 Z" />
       {/* Arms */}
      <path d="M150 170 C 130 180, 120 220, 120 260 L 125 380 L 145 380 L 140 260 C 140 220, 145 190, 150 180 Z" />
      <path d="M250 170 C 270 180, 280 220, 280 260 L 275 380 L 255 380 L 260 260 C 260 220, 255 190, 250 180 Z" />
      {/* Legs */}
      <path d="M155 340 L 140 550 L 180 550 L 175 340 Z" />
      <path d="M245 340 L 225 340 L 220 550 L 260 550 Z" />
    </g>
    <MuscleGroup id="pectoralis" d="M165 165 C 190 160, 190 160, 200 165 C 210 160, 210 160, 235 165 C 245 200, 230 240, 200 245 C 170 240, 155 200, 165 165 Z" {...props} />
    <MuscleGroup id="deltoids" d="M150 170 C 130 180, 120 220, 130 210 Q 150 150 165 165 M250 170 C 270 180, 280 220, 270 210 Q 250 150 235 165" {...props} />
    <MuscleGroup id="biceps" d="M130 215 C 140 220, 140 280, 130 285 L 122 280 C 122 270, 122 230, 128 220 Z M270 215 C 260 220, 260 280, 270 285 L 278 280 C 278 270, 278 230, 272 220 Z" {...props} />
    <MuscleGroup id="forearms" d="M127 295 C 135 300, 135 350, 127 355 L 122 350 C 122 340, 122 310, 125 300 Z M273 295 C 265 300, 265 350, 273 355 L 278 350 C 278 340, 278 310, 275 300 Z" {...props} />
    <MuscleGroup id="core" d="M170 250 H 230 V 335 H 170 Z" {...props} />
    <MuscleGroup id="quadriceps" d="M160 345 C 150 350, 140 450, 160 480 H 180 C 190 450, 180 350, 175 345 Z M225 345 C 220 350, 210 450, 220 480 H 240 C 250 450, 260 350, 240 345 Z" {...props} />
    <MuscleGroup id="calves" d="M148 490 C 140 500, 140 540, 150 545 H 165 C 170 540, 170 500, 162 490 Z M232 490 C 230 500, 230 540, 235 545 H 252 C 260 540, 260 500, 252 490 Z" {...props} />
  </svg>
);

// SVG paths for back view
// FIX: Use the new CommonMuscleProps type.
const BackView = (props: CommonMuscleProps) => (
  <svg viewBox="0 0 400 600" className="w-full h-auto max-w-sm">
    <g id="body-outline-back" className="fill-gray-800/80 stroke-gray-600 stroke-1">
      {/* Head */}
      <path d="M175 90 C 160 50, 240 50, 225 90 C 230 115, 215 130, 200 130 C 185 130, 170 115, 175 90 Z" />
      {/* Neck */}
      <path d="M190 130 L 185 150 H 215 L 210 130 Z" />
      {/* Torso */}
      <path d="M185 150 C 170 160, 150 180, 150 220 L 155 340 H 245 L 250 220 C 250 180, 230 160, 215 150 H 185 Z" />
       {/* Arms */}
      <path d="M150 170 C 130 180, 120 220, 120 260 L 125 380 L 145 380 L 140 260 C 140 220, 145 190, 150 180 Z" />
      <path d="M250 170 C 270 180, 280 220, 280 260 L 275 380 L 255 380 L 260 260 C 260 220, 255 190, 250 180 Z" />
      {/* Legs */}
      <path d="M155 340 L 140 550 L 180 550 L 175 340 Z" />
      <path d="M245 340 L 225 340 L 220 550 L 260 550 Z" />
    </g>
    <MuscleGroup id="trapezius" d="M190 140 L 170 160 L 180 220 L 200 240 L 220 220 L 230 160 L 210 140 Z" {...props} />
    <MuscleGroup id="rhomboids" d="M185 210 L 200 245 L 215 210 Z" {...props} />
    <MuscleGroup id="lats" d="M160 220 C 150 250, 150 300, 170 320 L 200 310 Z M240 220 C 250 250, 250 300, 230 320 L 200 310 Z" {...props} />
    <MuscleGroup id="triceps" d="M130 215 C 140 220, 140 280, 130 285 L 122 280 C 122 270, 122 230, 128 220 Z M270 215 C 260 220, 260 280, 270 285 L 278 280 C 278 270, 278 230, 272 220 Z" {...props} />
    <MuscleGroup id="glutes" d="M165 320 C 150 330, 150 380, 170 390 H 230 C 250 380, 250 330, 235 320 Z" {...props} />
    <MuscleGroup id="hamstrings" d="M160 395 C 155 400, 155 480, 160 485 H 175 C 180 480, 180 400, 175 395 Z M225 395 C 220 400, 220 480, 225 485 H 240 C 245 480, 245 400, 240 395 Z" {...props} />
    <MuscleGroup id="calves" d="M150 490 C 145 500, 145 540, 150 545 H 165 C 170 540, 170 500, 165 490 Z M235 490 C 230 500, 230 540, 235 545 H 250 C 255 540, 255 500, 250 490 Z" {...props} />
    <MuscleGroup id="deltoids" d="M150 170 C 130 180, 120 220, 130 210 Q 150 150 165 165 M250 170 C 270 180, 280 220, 270 210 Q 250 150 235 165" {...props} />
    <MuscleGroup id="forearms" d="M127 295 C 135 300, 135 350, 127 355 L 122 350 C 122 340, 122 310, 125 300 Z M273 295 C 265 300, 265 350, 273 355 L 278 350 C 278 340, 278 310, 275 300 Z" {...props} />
  </svg>
);


export const MuscleMap: React.FC<MuscleMapProps> = ({ view, ...props }) => {
  return (
    <div className="w-full h-full flex flex-col items-center">
      <h3 className="text-xl font-bold capitalize mb-2 text-gray-400">{view} View</h3>
       {view === 'front' ? <FrontView {...props} /> : <BackView {...props} />}
    </div>
  );
};
