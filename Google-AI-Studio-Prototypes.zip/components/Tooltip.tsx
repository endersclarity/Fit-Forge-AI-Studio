
import React from 'react';

interface TooltipProps {
  muscleName: string;
  fatiguePercentage: number;
  position: { x: number; y: number };
}

export const Tooltip: React.FC<TooltipProps> = ({ muscleName, fatiguePercentage, position }) => {
  return (
    <div
      className="absolute p-3 bg-gray-900/80 border border-gray-600 rounded-lg shadow-xl pointer-events-none transform -translate-x-1/2 -translate-y-full -mt-2 transition-opacity duration-200"
      style={{ left: position.x, top: position.y }}
    >
      <p className="font-bold text-lg text-emerald-400">{muscleName}</p>
      <p className="text-gray-300">{fatiguePercentage}% Fatigued</p>
    </div>
  );
};
