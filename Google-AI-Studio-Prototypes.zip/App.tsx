
import React, { useState, useCallback } from 'react';
import { MuscleVisualization } from './components/MuscleVisualization';
import { MuscleState, MuscleId, MUSCLE_IDS } from './types';
import { MUSCLE_NAMES } from './constants';

const initialMuscleState: MuscleState[] = MUSCLE_IDS.map(id => ({
  muscleId: id,
  fatiguePercentage: Math.floor(Math.random() * 101),
}));

const App: React.FC = () => {
  const [muscles, setMuscles] = useState<MuscleState[]>(initialMuscleState);
  const [logs, setLogs] = useState<string[]>([]);
  const [hideTooltip, setHideTooltip] = useState<boolean>(false);

  const addLog = useCallback((message: string) => {
    setLogs(prev => [`${new Date().toLocaleTimeString()}: ${message}`, ...prev.slice(0, 9)]);
  }, []);

  const handleMuscleClick = useCallback((muscleId: string) => {
    addLog(`Clicked: ${MUSCLE_NAMES[muscleId as MuscleId]}`);
  }, [addLog]);

  const handleMuscleHover = useCallback((muscleId: string | null) => {
    if (muscleId) {
      addLog(`Hovered: ${MUSCLE_NAMES[muscleId as MuscleId]}`);
    } else {
      addLog('Hovered off');
    }
  }, [addLog]);

  const updateFatigue = (muscleId: MuscleId, value: number) => {
    setMuscles(prev =>
      prev.map(m => (m.muscleId === muscleId ? { ...m, fatiguePercentage: value } : m))
    );
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200 font-sans p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-4xl sm:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-500">
            FitForge Muscle Visualization
          </h1>
          <p className="mt-2 text-lg text-gray-400">
            An interactive component to visualize muscle fatigue.
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <main className="lg:col-span-2 bg-gray-800/50 p-4 sm:p-6 rounded-2xl shadow-2xl border border-gray-700">
            <MuscleVisualization
              muscles={muscles}
              onMuscleClick={handleMuscleClick}
              onMuscleHover={handleMuscleHover}
              hideTooltip={hideTooltip}
            />
          </main>

          <aside className="space-y-6">
            <div className="bg-gray-800/50 p-6 rounded-2xl shadow-lg border border-gray-700">
              <h2 className="text-2xl font-bold mb-4 text-emerald-400">Controls</h2>
              <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
                {muscles.map(({ muscleId, fatiguePercentage }) => (
                  <div key={muscleId}>
                    <label htmlFor={muscleId} className="block mb-1 text-sm font-medium text-gray-300">
                      {MUSCLE_NAMES[muscleId]} ({fatiguePercentage}%)
                    </label>
                    <input
                      id={muscleId}
                      type="range"
                      min="0"
                      max="100"
                      value={fatiguePercentage}
                      onChange={(e) => updateFatigue(muscleId, parseInt(e.target.value, 10))}
                      className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                    />
                  </div>
                ))}
              </div>
               <div className="mt-6 flex items-center">
                <input
                  type="checkbox"
                  id="hideTooltip"
                  checked={hideTooltip}
                  onChange={(e) => setHideTooltip(e.target.checked)}
                  className="h-4 w-4 rounded border-gray-600 bg-gray-700 text-emerald-500 focus:ring-emerald-600"
                />
                <label htmlFor="hideTooltip" className="ml-2 block text-sm text-gray-300">
                  Hide Tooltip
                </label>
              </div>
            </div>

            <div className="bg-gray-800/50 p-6 rounded-2xl shadow-lg border border-gray-700">
              <h2 className="text-2xl font-bold mb-4 text-cyan-400">Event Logs</h2>
              <div className="h-64 bg-gray-900 rounded-lg p-3 font-mono text-sm text-gray-400 overflow-y-auto flex flex-col-reverse">
                {logs.length > 0 ? (
                  logs.map((log, i) => <p key={i} className="whitespace-pre-wrap">{log}</p>)
                ) : (
                  <p>Interact with the model to see logs...</p>
                )}
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
};

export default App;
