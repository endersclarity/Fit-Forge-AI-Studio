
import { MuscleId } from './types';

export const MUSCLE_NAMES: Record<MuscleId, string> = {
  pectoralis: 'Pectoralis',
  deltoids: 'Deltoids',
  triceps: 'Triceps',
  biceps: 'Biceps',
  lats: 'Lats',
  rhomboids: 'Rhomboids',
  trapezius: 'Trapezius',
  forearms: 'Forearms',
  core: 'Core',
  quadriceps: 'Quadriceps',
  hamstrings: 'Hamstrings',
  glutes: 'Glutes',
  calves: 'Calves',
};
