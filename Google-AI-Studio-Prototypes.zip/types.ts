
export const MUSCLE_IDS = [
  'pectoralis', 'deltoids', 'triceps', 'biceps', 'lats', 'rhomboids', 
  'trapezius', 'forearms', 'core', 'quadriceps', 'hamstrings', 'glutes', 'calves'
] as const;

export type MuscleId = typeof MUSCLE_IDS[number];

export interface MuscleState {
  muscleId: MuscleId;
  fatiguePercentage: number; // 0-100
}

export interface MuscleVisualizationProps {
  muscles: MuscleState[];
  onMuscleClick?: (muscleId: MuscleId) => void;
  onMuscleHover?: (muscleId: MuscleId | null) => void;
  width?: number | string;
  height?: number | string;
  hideTooltip?: boolean;
}

export interface TooltipData {
  muscleId: MuscleId;
  fatiguePercentage: number;
  x: number;
  y: number;
}
